
main1(0);
main1(1);
main2(0);
main2(1);
main1(2);
main1(3);
main2(2);
main2(3);